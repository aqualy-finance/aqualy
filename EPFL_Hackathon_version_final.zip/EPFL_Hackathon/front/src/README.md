
  # Project Base Setup

  This is a code bundle for Project Base Setup. The original project is available at https://www.figma.com/design/B8vNYz9ixU1IAAYHfaGTux/Project-Base-Setup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  